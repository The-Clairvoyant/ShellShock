# Shellshock Burp Plugin
A burp plugin to provide active scanning for CVE-2014-6271 against Apache's MOD_CGI. 

## Download
Compiled to Java 6 for luddites and the like.

> [Download here!](https://github.com/AccuvantLabs-Appsec/burpshellshock/releases/download/1.0/burpshellshock-1.0-SNAPSHOT-jar-with-dependencies.jar)

## Building

> mvn package
